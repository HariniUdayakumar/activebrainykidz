sources:
http://www.smashingmagazine.com/2010/06/22/free-portfolio-psd-template-bluemasters/


some resources taken from:
http://demo.marioaguiar.com/wp/